# Python-Bot
This is a  chatbot made in python which could take basic commands given to it by speech
# Langugage
- python
